COMO CORRER EL PROGRAMA:

1) Primero en la terminal, dirígete a donde tengas el archivo
2) Compila el archivo con este comando "gcc -o Practica2 Practica2.c -lm" 
3) Ejecuta con "./Practica2 Practica2 A 4.3 8.2 2.4 6.6 8.8 9.1 0.1" de donde...
	-> ./Practica2 es el nombre del archivo dado por "-o Practica2"
	-> Practica2 es el nombre del programa
	-> A es la media que queremos, intercambiable por H ó G (aritmética, armónica ó geométrica)
	-> "4.3 8.2 … " son los datos que queremos probar, intercambiables por los datos que desees (númericos)


